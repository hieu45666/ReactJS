function Footer() {
    return (
        <footer class="page-footer font-small bg-dark">
            <div class="footer-copyright text-center py-3">© 2021 Copyright</div>
        </footer>
    )
}
export default Footer;