import {combineReducers} from "redux";
import productList from "../Product/ProductReducer";

export default combineReducers({
    productList,
})